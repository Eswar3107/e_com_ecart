package ProductsModel;

public class Order {
 private int order_id;

 				
 private int ordr_cust_id;		
 private int ordr_billno	;	
 private String ordr_odate	;		
 private int ordr_total		;	
 private int ordr_gst		;	
 private int ordr_payreference;		
 private String ordr_paymode	;			
 private String ordr_paystatus	;		
 private String ordr_saddress	;			
 private String ordr_shipment_status;		
 private String ordr_shipment_date;		
 private int ordr_processedby		;
public Order(int order_id, int ordr_cust_id, int ordr_billno, String ordr_odate, int ordr_total, int ordr_gst,
		int ordr_payreference, String ordr_paymode, String ordr_paystatus, String ordr_saddress,
		String ordr_shipment_status, String ordr_shipment_date, int ordr_processedby) {
	super();
	this.order_id = order_id;
	this.ordr_cust_id = ordr_cust_id;
	this.ordr_billno = ordr_billno;
	this.ordr_odate = ordr_odate;
	this.ordr_total = ordr_total;
	this.ordr_gst = ordr_gst;
	this.ordr_payreference = ordr_payreference;
	this.ordr_paymode = ordr_paymode;
	this.ordr_paystatus = ordr_paystatus;
	this.ordr_saddress = ordr_saddress;
	this.ordr_shipment_status = ordr_shipment_status;
	this.ordr_shipment_date = ordr_shipment_date;
	this.ordr_processedby = ordr_processedby;
}
public int getOrder_id() {
	return order_id;
}
public void setOrder_id(int order_id) {
	this.order_id = order_id;
}
public int getOrdr_cust_id() {
	return ordr_cust_id;
}
public void setOrdr_cust_id(int ordr_cust_id) {
	this.ordr_cust_id = ordr_cust_id;
}
public int getOrdr_billno() {
	return ordr_billno;
}
public void setOrdr_billno(int ordr_billno) {
	this.ordr_billno = ordr_billno;
}
public String getOrdr_odate() {
	return ordr_odate;
}
public void setOrdr_odate(String ordr_odate) {
	this.ordr_odate = ordr_odate;
}
public int getOrdr_total() {
	return ordr_total;
}
public void setOrdr_total(int ordr_total) {
	this.ordr_total = ordr_total;
}
public int getOrdr_gst() {
	return ordr_gst;
}
public void setOrdr_gst(int ordr_gst) {
	this.ordr_gst = ordr_gst;
}
public int getOrdr_payreference() {
	return ordr_payreference;
}
public void setOrdr_payreference(int ordr_payreference) {
	this.ordr_payreference = ordr_payreference;
}
public String getOrdr_paymode() {
	return ordr_paymode;
}
public void setOrdr_paymode(String ordr_paymode) {
	this.ordr_paymode = ordr_paymode;
}
public String getOrdr_paystatus() {
	return ordr_paystatus;
}
public void setOrdr_paystatus(String ordr_paystatus) {
	this.ordr_paystatus = ordr_paystatus;
}
public String getOrdr_saddress() {
	return ordr_saddress;
}
public void setOrdr_saddress(String ordr_saddress) {
	this.ordr_saddress = ordr_saddress;
}
public String getOrdr_shipment_status() {
	return ordr_shipment_status;
}
public void setOrdr_shipment_status(String ordr_shipment_status) {
	this.ordr_shipment_status = ordr_shipment_status;
}
public String getOrdr_shipment_date() {
	return ordr_shipment_date;
}
public void setOrdr_shipment_date(String ordr_shipment_date) {
	this.ordr_shipment_date = ordr_shipment_date;
}
public int getOrdr_processedby() {
	return ordr_processedby;
}
public void setOrdr_processedby(int ordr_processedby) {
	this.ordr_processedby = ordr_processedby;
}	

}
