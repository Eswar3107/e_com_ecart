// package ProductsService;
//
// import java.util.List;
//
// import ProductsDAO.AdminDAO;
// import ProductsModel.Product;
//
// public class AdminService {
//
// public AdminService(AdminDAO adminDAO) {
// this.adminDAO = adminDAO;
// }
//
// public List<Product> getAllProducts() {
// return adminDAO.getAllOrders();
// }
//
// }
